-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 20, 2022 at 02:14 AM
-- Server version: 10.3.35-MariaDB-cll-lve
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wsfiyuve_schoolmanagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `class_times`
--

CREATE TABLE `class_times` (
  `id` int(10) UNSIGNED NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `day` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teacher` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `room_number` int(11) NOT NULL DEFAULT 101,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `class_times`
--

INSERT INTO `class_times` (`id`, `class`, `section`, `subject`, `start_time`, `end_time`, `day`, `teacher`, `room_number`, `created_at`, `updated_at`) VALUES
(9, 'Class one', 'A', 'Digital System', '12:01:26', '12:01:26', 'Sunday', '1', 101, '2022-08-14 21:04:46', '2022-08-14 21:04:46'),
(10, 'Class one', 'A', 'Algorithm', '12:01:26', '12:01:26', 'Sunday', '1', 101, '2022-08-14 21:04:46', '2022-08-14 21:04:46'),
(11, 'Class one', 'A', 'Algorithm', '12:01:26', '12:01:26', 'Sunday', '1', 101, '2022-08-14 21:04:46', '2022-08-14 21:04:46'),
(12, 'Class one', 'A', 'Digital System', '12:01:26', '12:01:26', 'Monday', '1', 101, '2022-08-14 21:39:22', '2022-08-14 21:39:22'),
(13, 'Class one', 'A', 'Algorithm', '12:01:26', '12:01:26', 'Friday', '1', 101, '2022-08-14 21:39:22', '2022-08-14 21:39:22'),
(14, 'Class one', 'A', 'Algorithm', '12:01:26', '12:01:26', 'Sunday', '1', 101, '2022-08-14 21:39:22', '2022-08-14 21:39:22'),
(15, 'Class one', 'A', 'Digital System', '12:01:26', '12:01:26', 'Monday', '1', 101, '2022-08-14 21:40:09', '2022-08-14 21:40:09'),
(16, 'Class one', 'A', 'Algorithm', '12:01:26', '12:01:26', 'Friday', '1', 101, '2022-08-14 21:40:09', '2022-08-14 21:40:09'),
(17, 'Class one', 'A', 'Algorithm', '12:01:26', '12:01:26', 'Tuesday', '1', 101, '2022-08-14 21:40:09', '2022-08-14 21:40:09'),
(18, 'Class one', 'A', 'Digital System', '12:01:26', '12:01:26', 'Monday', '1', 101, '2022-08-16 15:40:38', '2022-08-16 15:40:38'),
(19, 'Class one', 'A', 'Algorithm', '12:01:26', '12:01:26', 'Friday', '1', 101, '2022-08-16 15:40:38', '2022-08-16 15:40:38'),
(20, 'Class one', 'A', 'Algorithm', '12:01:26', '12:01:26', 'Tuesday', '1', 101, '2022-08-16 15:40:38', '2022-08-16 15:40:38');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permanent_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_account_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_salary` decimal(10,2) DEFAULT NULL,
  `nid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blood_group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employee_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `user_name`, `name`, `mobile`, `email`, `current_address`, `permanent_address`, `bank_account_number`, `bank_name`, `bank_code`, `total_salary`, `nid`, `blood_group`, `employee_type`, `password`, `created_at`, `updated_at`) VALUES
(6, 'test.teacher', 'Test Teacher', '01720515258', 'teacher1@gmail.com', '211 dhaka', '211 dhaka', 'adjad44ag', 'Bangladesh bank', NULL, '4265.00', '546545135', 'A+(ve)', '1', '$2y$10$KasTbIWfN2LCYo1Y0OxlWe6QiAiznbwnbbQlYetzclNC/vovMSjEa', '2022-08-14 04:54:38', '2022-08-14 04:54:38');

-- --------------------------------------------------------

--
-- Table structure for table `employee_attendances`
--

CREATE TABLE `employee_attendances` (
  `id` int(10) UNSIGNED NOT NULL,
  `emp_id` int(11) NOT NULL,
  `attendance_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `remark` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_attendances`
--

INSERT INTO `employee_attendances` (`id`, `emp_id`, `attendance_date`, `remark`, `created_at`, `updated_at`) VALUES
(1, 1, '2022-02-05 18:00:00', 1, '2022-08-06 08:42:55', '2022-08-06 08:42:55'),
(2, 1, '2022-02-05 18:00:00', 1, '2022-08-06 08:49:10', '2022-08-06 08:49:10');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(10) UNSIGNED NOT NULL,
  `exam_type` int(11) NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_marks` int(11) NOT NULL,
  `teacher` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exam_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `room_number` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`id`, `exam_type`, `class`, `total_marks`, `teacher`, `subject`, `guard`, `exam_date`, `start_time`, `end_time`, `room_number`, `created_at`, `updated_at`) VALUES
(1, 1, 'Class one', 1254, '1', 'Digital System', 'Guard 1', '2022-08-16 07:43:11', '12:01:26', '12:01:26', 24446, '2022-08-16 17:43:11', '2022-08-16 17:43:11'),
(2, 1, 'Class one', 1254, '1', 'English', 'Guard 1', '2022-08-16 07:43:11', '12:01:26', '12:01:26', 24446, '2022-08-16 17:43:11', '2022-08-16 17:43:11');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `id` int(255) NOT NULL,
  `details` varchar(1000) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `date` varchar(255) NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`id`, `details`, `amount`, `date`, `payment_method`, `created_at`) VALUES
(2, 'Income', '3000.00', '2022-08-04 08:11:24', '', '2022-08-10 05:05:40'),
(3, 'Income', '3000.00', '2022-08-04 08:11:24', '', '2022-08-10 05:05:50'),
(4, 'Income', '3000.00', '2022-08-04 08:11:24', '', '2022-08-10 05:05:51'),
(5, 'Income', '30000.00', '2022-08-04 08:11:24', 'cash', '2022-08-10 06:04:24');

-- --------------------------------------------------------

--
-- Table structure for table `expense_income_type`
--

CREATE TABLE `expense_income_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expense_income_type`
--

INSERT INTO `expense_income_type` (`id`, `name`, `type`) VALUES
(1, 'abc', 'xyzac'),
(2, 'abc', 'xyz');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE `fees` (
  `id` int(10) UNSIGNED NOT NULL,
  `std_id` int(11) NOT NULL,
  `payable_amount` decimal(10,2) NOT NULL,
  `pay` decimal(10,2) NOT NULL,
  `discount_amount` decimal(10,2) NOT NULL,
  `payment_status` int(11) NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fees_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fees_total_payable`
--

CREATE TABLE `fees_total_payable` (
  `id` int(255) NOT NULL,
  `std_id` int(11) NOT NULL,
  `total_payable` decimal(10,0) NOT NULL,
  `pay` decimal(10,0) NOT NULL,
  `due` decimal(10,0) NOT NULL,
  `details` varchar(1000) NOT NULL,
  `payment_last_date` timestamp NULL DEFAULT NULL,
  `pay_date` timestamp NULL DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fees_total_payable`
--

INSERT INTO `fees_total_payable` (`id`, `std_id`, `total_payable`, `pay`, `due`, `details`, `payment_last_date`, `pay_date`, `status`, `created_at`, `updated_at`) VALUES
(9, 1, '100000', '1000', '99000', 'Write About This', '2024-08-04 02:11:24', '2022-08-04 02:11:24', 0, '2022-08-13 07:04:48', NULL),
(11, 2, '100000', '1000', '99000', 'Write About This', '2024-08-04 12:11:24', '2022-08-04 12:11:24', 1, '2022-08-20 04:58:12', NULL),
(12, 3, '100000', '1000', '99000', 'Write About This', '2024-08-04 12:11:24', '2022-08-04 12:11:24', 1, '2022-08-20 04:58:16', NULL),
(13, 4, '100000', '1000', '99000', 'Write About This', '2024-08-04 12:11:24', '2022-08-04 12:11:24', 1, '2022-08-20 04:58:29', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `fines`
--

CREATE TABLE `fines` (
  `id` int(255) NOT NULL,
  `std_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `note` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `homework`
--

CREATE TABLE `homework` (
  `id` int(10) UNSIGNED NOT NULL,
  `create_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `submission_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `income`
--

CREATE TABLE `income` (
  `id` int(11) NOT NULL,
  `details` varchar(1000) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `date` varchar(255) NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `income`
--

INSERT INTO `income` (`id`, `details`, `amount`, `date`, `payment_method`, `created_at`) VALUES
(2, 'Income', '3000.00', '2022-08-04 08:11:24', '', '2022-08-10 05:02:22'),
(3, 'Income', '3000.00', '2022-08-04 08:11:24', '', '2022-08-10 05:03:00'),
(4, 'Income', '3000.00', '2022-08-04 08:11:24', 'bkash', '2022-08-10 06:03:36');

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

CREATE TABLE `leaves` (
  `id` int(10) UNSIGNED NOT NULL,
  `std_id` int(11) NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `to_date` timestamp NOT NULL DEFAULT '2022-08-06 06:13:05',
  `apply_date` timestamp NOT NULL DEFAULT '2022-08-06 06:13:05',
  `type` int(11) NOT NULL,
  `approve_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leaves`
--

INSERT INTO `leaves` (`id`, `std_id`, `status`, `from_date`, `to_date`, `apply_date`, `type`, `approve_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'Pending', '2012-01-25 18:00:00', '2012-01-25 18:00:00', '2012-01-25 18:00:00', 1, NULL, '2022-08-06 06:14:37', '2022-08-06 06:14:37');

-- --------------------------------------------------------

--
-- Table structure for table `list_class`
--

CREATE TABLE `list_class` (
  `id` int(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `list_class`
--

INSERT INTO `list_class` (`id`, `class`, `section`) VALUES
(2, 'five', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `list_section`
--

CREATE TABLE `list_section` (
  `id` int(255) NOT NULL,
  `section_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `list_subject`
--

CREATE TABLE `list_subject` (
  `id` int(255) NOT NULL,
  `section_name` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `list_subject`
--

INSERT INTO `list_subject` (`id`, `section_name`, `class`, `subject`, `created_at`) VALUES
(2, 'A', 'five', 'Bangla', '2022-08-14 04:01:54');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(37, '2014_10_12_000000_create_users_table', 1),
(248, '2014_10_12_100000_create_password_resets_table', 2),
(249, '2019_08_19_000000_create_failed_jobs_table', 2),
(250, '2019_12_14_000001_create_personal_access_tokens_table', 2),
(251, '2022_07_31_060233_create_students_table', 2),
(252, '2022_07_31_093304_create_parents_table', 2),
(253, '2022_07_31_093751_create_employees_table', 2),
(254, '2022_07_31_094302_create_employee_attendances_table', 2),
(255, '2022_07_31_094553_create_salaries_table', 2),
(256, '2022_07_31_094949_create_homework_table', 2),
(257, '2022_07_31_100051_create_exams_table', 2),
(258, '2022_07_31_100518_create_student_reports_table', 2),
(259, '2022_07_31_101238_create_class_times_table', 2),
(261, '2022_07_31_101521_create_notices_table', 2),
(262, '2022_07_31_101703_create_payment_details_table', 2),
(264, '2022_07_31_102043_create_student_attendances_table', 2),
(265, '2022_08_04_080347_create_users_table', 2),
(267, '2022_07_31_101401_create_leaves_table', 3),
(269, '2022_07_31_101851_create_fees_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `id` int(10) UNSIGNED NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`id`, `subject`, `details`, `file`, `date`, `created_at`, `updated_at`) VALUES
(1, 'This is the title for notificatin', 'Thi is the body for title', '1659764003.jpg', '2022-08-05 23:33:23', '2022-08-05 23:33:23', '2022-08-05 23:33:23'),
(2, 'This is the title for notificatin', 'Thi is the body for title', '1659764254.jpg', '2022-08-06 05:37:34', '2022-08-06 05:37:34', '2022-08-06 05:37:34'),
(3, 'This is the title for notificatin', 'Thi is the body for title', '1660970671.docx', '2022-08-20 14:44:31', '2022-08-20 14:44:31', '2022-08-20 14:44:31'),
(4, 'This is the title for notificatin', 'Thi is the body for title', '1660970926.svg', '2022-08-20 14:48:46', '2022-08-20 14:48:46', '2022-08-20 14:48:46'),
(5, 'This is the title for notificatin', 'Thi is the body for title', '1660971247.svg', '2022-08-20 14:54:07', '2022-08-20 14:54:07', '2022-08-20 14:54:07');

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `std_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `occupation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relation` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permanent_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_account_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `back_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `parents`
--

INSERT INTO `parents` (`id`, `user_name`, `std_id`, `name`, `occupation`, `relation`, `email`, `current_address`, `permanent_address`, `bank_account_number`, `bank_name`, `back_code`, `nid`, `password`, `created_at`, `updated_at`) VALUES
(1, 'test.parent', 1, 'Test Parent', 'job', 1, 'parent1@gmail.com', '211 dhaka', '211 dhaka', 'adjad44ag', 'Bangladesh bank', '55222', '546545135', '$2y$10$T60eq.2Ss1lUCuB49iU25e1mFBe14uFAalyj/D1QHc0q0eZabp5jW', '2022-08-14 14:02:10', '2022-08-14 14:02:10');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_details`
--

CREATE TABLE `payment_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `payment_type` int(11) NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `opening_balace` decimal(10,2) DEFAULT 0.00,
  `current_balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `bank_name`, `account_name`, `opening_balace`, `current_balance`, `created_at`) VALUES
(1, 'DBBL', 'MD Rakib Miah', '0.00', '10.00', '2022-08-10 07:34:01'),
(2, 'DBBL', 'MD Rakib Miah', '0.00', '12.00', '2022-08-10 07:34:24'),
(4, 'DBBL', 'MD Rakib Miah', '0.00', '12.00', '2022-08-10 07:36:45');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 2, 'myToken', 'c4389698120bea0d8ec4c0e7c27a493b6739a63596c036ab7180762974c1461d', '[\"*\"]', NULL, NULL, '2022-08-08 15:13:25', '2022-08-08 15:13:25'),
(2, 'App\\Models\\User', 2, 'myToken', '5b2db485aa05d82edd0fcda89f0bb79f2be2afcb6b33178e60ee6a29fd867911', '[\"*\"]', NULL, NULL, '2022-08-08 15:13:50', '2022-08-08 15:13:50'),
(3, 'App\\Models\\User', 2, 'myToken', '17ee05b4f3ba5bbc24394d0755551216a63b551a56f46227c881972b4ed7536d', '[\"*\"]', NULL, NULL, '2022-08-11 10:26:10', '2022-08-11 10:26:10'),
(4, 'App\\Models\\User', 3, 'myToken', '493fda9e4b066ca16e0bd546600ce896bda839447cec1486ae7d1d368793951d', '[\"*\"]', NULL, NULL, '2022-08-14 14:02:10', '2022-08-14 14:02:10'),
(5, 'App\\Models\\User', 3, 'myToken', 'b339488c16bfb143b26c97be6f656471c5358f73e9b8d649ac850b5291aaf2a7', '[\"*\"]', NULL, NULL, '2022-08-14 14:02:14', '2022-08-14 14:02:14'),
(6, 'App\\Models\\User', 3, 'myToken', '51a4316087085b0a7bbc95148ba3c48e4e945c177ff648a6aa547de4b1626436', '[\"*\"]', '2022-08-14 14:22:12', NULL, '2022-08-14 14:22:11', '2022-08-14 14:22:12'),
(7, 'App\\Models\\User', 4, 'myToken', '655808263796519190199d64e87211eb28769fa160a9cffda53364426de8431a', '[\"*\"]', NULL, NULL, '2022-08-14 14:54:38', '2022-08-14 14:54:38'),
(8, 'App\\Models\\User', 4, 'myToken', 'baab7db72c2c7ff79ef0b6f5210d2489402aa61e0b2c676512e4b3b71ba22a06', '[\"*\"]', '2022-08-14 15:11:02', NULL, '2022-08-14 14:55:12', '2022-08-14 15:11:02'),
(9, 'App\\Models\\User', 4, 'myToken', 'c7c9043372d4e160c6e29ead6ecdb9d05f5a87ab02ca6ffa1497ef8221c7b826', '[\"*\"]', '2022-08-14 15:33:01', NULL, '2022-08-14 15:33:00', '2022-08-14 15:33:01'),
(10, 'App\\Models\\User', 2, 'myToken', '347012b77e3a21e8c5d0e7540f33a75cf7c40bdec23d76a866fcb97852837abe', '[\"*\"]', NULL, NULL, '2022-08-14 16:02:24', '2022-08-14 16:02:24'),
(11, 'App\\Models\\User', 2, 'myToken', 'af89b2878e5a1b3ec00091f16300337633a8f0e2fae26e2cff7c37c5a33d6f6f', '[\"*\"]', '2022-08-14 19:16:41', NULL, '2022-08-14 16:02:47', '2022-08-14 19:16:41'),
(12, 'App\\Models\\User', 4, 'myToken', '5ab0344680d590154d5221289e49d1a5474d484837c7b544d241b52c76fd922c', '[\"*\"]', '2022-08-14 19:42:09', NULL, '2022-08-14 17:22:13', '2022-08-14 19:42:09'),
(13, 'App\\Models\\User', 4, 'myToken', '79424a87fdb5f7fdfc50440cea6caf5c669390e3b059f86a29a0c12f3f20db49', '[\"*\"]', '2022-08-14 17:36:16', NULL, '2022-08-14 17:33:42', '2022-08-14 17:36:16'),
(14, 'App\\Models\\User', 5, 'myToken', 'b2620b9daed5f44f3ce923ada4309c001fe3f171936321505b24b91814c37e55', '[\"*\"]', NULL, NULL, '2022-08-14 19:46:20', '2022-08-14 19:46:20'),
(15, 'App\\Models\\User', 5, 'myToken', 'edc9ea78ad5691ea873dfc9f960788f51f627612ca49ceaa51e78aa7f292bf93', '[\"*\"]', '2022-08-14 19:47:26', NULL, '2022-08-14 19:47:01', '2022-08-14 19:47:26'),
(16, 'App\\Models\\User', 5, 'myToken', '30836da1e6d629d0f2768b8a62ada5c65dd642013d71fcb21e1f0fbed339e28c', '[\"*\"]', '2022-08-14 20:06:03', NULL, '2022-08-14 19:58:24', '2022-08-14 20:06:03'),
(17, 'App\\Models\\User', 5, 'myToken', 'a696088c15ed7953011584df0f3d42f885453f89afd5cf2ad22870d11267c2d1', '[\"*\"]', '2022-08-14 20:09:42', NULL, '2022-08-14 20:06:48', '2022-08-14 20:09:42'),
(18, 'App\\Models\\User', 2, 'myToken', 'e98ad516b443d1e981364ba6f72ca7dc8aea391f388bcb6d596ae22b105422d3', '[\"*\"]', '2022-08-14 20:22:13', NULL, '2022-08-14 20:22:12', '2022-08-14 20:22:13'),
(19, 'App\\Models\\User', 2, 'myToken', 'a2a3a928a9143c6d3ca33c5dda46d37ef26b4e9ffdf3ba93a5dc73e8dfec7caa', '[\"*\"]', '2022-08-14 21:08:44', NULL, '2022-08-14 20:41:23', '2022-08-14 21:08:44'),
(20, 'App\\Models\\User', 2, 'myToken', '9879cc85c509c5c3245209ba64dc8c61ba940b4a27299674a4e4125253583980', '[\"*\"]', '2022-08-14 21:14:21', NULL, '2022-08-14 21:09:30', '2022-08-14 21:14:21'),
(21, 'App\\Models\\User', 2, 'myToken', 'a7241728ec9a6a22668e97d9a37086844cccbbff1416e9ea3cd1528c631bbd2c', '[\"*\"]', '2022-08-16 14:56:55', NULL, '2022-08-14 21:15:09', '2022-08-16 14:56:55'),
(22, 'App\\Models\\User', 5, 'myToken', '21f4aa6ca7caf2ff75703e9e228cea42a405d582c15d35079f07707786efd541', '[\"*\"]', '2022-08-14 21:43:29', NULL, '2022-08-14 21:21:56', '2022-08-14 21:43:29'),
(23, 'App\\Models\\User', 5, 'myToken', 'e5dc077e970a7d17e5fd01b9fcc5129cc6d7c89c291ddc10984ae12a26e3f142', '[\"*\"]', '2022-08-14 21:52:31', NULL, '2022-08-14 21:31:54', '2022-08-14 21:52:31'),
(24, 'App\\Models\\User', 5, 'myToken', '964902c680870c401a92823ada6e577107e6f6b171d350b8418031969036521d', '[\"*\"]', '2022-08-14 21:44:56', NULL, '2022-08-14 21:44:55', '2022-08-14 21:44:56'),
(25, 'App\\Models\\User', 4, 'myToken', '3f60fc97b398d9ca5d9f2aaa0b866fa8975aa3803d085ff852bc174601a07523', '[\"*\"]', '2022-08-16 13:27:30', NULL, '2022-08-14 21:45:29', '2022-08-16 13:27:30'),
(26, 'App\\Models\\User', 4, 'myToken', '5f7ec8a2d1580b8f10d1f623009588e6b918e6c11126f041fdc2efade3a3fc92', '[\"*\"]', '2022-08-16 19:38:28', NULL, '2022-08-16 13:54:12', '2022-08-16 19:38:28'),
(27, 'App\\Models\\User', 2, 'myToken', '8f1e16453725803fd6bb4625414043d1520fdfa49af9f1f3a9a1469ab79b88b8', '[\"*\"]', '2022-08-16 17:21:47', NULL, '2022-08-16 15:02:55', '2022-08-16 17:21:47'),
(28, 'App\\Models\\User', 2, 'myToken', '5711bfdcff7bf772bf709e4be9d794ec59d04319d22cff92487e4be4f025459d', '[\"*\"]', NULL, NULL, '2022-08-16 17:23:28', '2022-08-16 17:23:28'),
(29, 'App\\Models\\User', 2, 'myToken', '6332fc526ab2e052431ee8e681d65995b2480aa84a181e135cfc221373de55d5', '[\"*\"]', '2022-08-16 18:37:26', NULL, '2022-08-16 17:24:01', '2022-08-16 18:37:26'),
(30, 'App\\Models\\User', 4, 'myToken', '51f8dfda0049b75e8881bb6f36f73a990b29ad6de2f2a55d42af34ecedebce53', '[\"*\"]', NULL, NULL, '2022-08-16 18:43:51', '2022-08-16 18:43:51'),
(31, 'App\\Models\\User', 4, 'myToken', 'f175c251550c82b596e4c4ff08cea07f3a857fe71e348a8adadf0cae93155721', '[\"*\"]', '2022-08-16 18:48:30', NULL, '2022-08-16 18:47:16', '2022-08-16 18:48:30'),
(32, 'App\\Models\\User', 5, 'myToken', 'e77d48b724505dd5ace2f3962c4169b7a2b611e188bd85990a9a46826aee9833', '[\"*\"]', '2022-08-16 19:39:26', NULL, '2022-08-16 19:39:26', '2022-08-16 19:39:26'),
(33, 'App\\Models\\User', 5, 'myToken', '46913f12fa9fd0c76bae822d2a40b55c6a9d3a07e59cc67244a8b1d4505976c6', '[\"*\"]', '2022-08-16 19:41:15', NULL, '2022-08-16 19:41:14', '2022-08-16 19:41:15'),
(34, 'App\\Models\\User', 2, 'myToken', '50c8d5f67d6c1afb1b10e7056e8774d0f20cd70f6616968a383ef3b0ac9b4d80', '[\"*\"]', NULL, NULL, '2022-08-20 14:57:08', '2022-08-20 14:57:08');

-- --------------------------------------------------------

--
-- Table structure for table `reports_guardian`
--

CREATE TABLE `reports_guardian` (
  `id` int(255) NOT NULL,
  `guardian_name` varchar(100) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `relation` varchar(100) NOT NULL,
  `class` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `reg_no` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reports_guardian`
--

INSERT INTO `reports_guardian` (`id`, `guardian_name`, `student_name`, `relation`, `class`, `section`, `reg_no`, `created_at`) VALUES
(1, 'guardian_name', 'student_name', 'relation', 'class', 'section', 'reg_no', '2022-08-11 09:15:39');

-- --------------------------------------------------------

--
-- Table structure for table `salaries`
--

CREATE TABLE `salaries` (
  `id` int(10) UNSIGNED NOT NULL,
  `emp_id` int(11) NOT NULL,
  `employee_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `payment_month` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `due_amount` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `paid_amount` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(10) UNSIGNED NOT NULL,
  `registration_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` int(11) NOT NULL DEFAULT 0,
  `birth_registration_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roll` int(11) NOT NULL DEFAULT 0,
  `section` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admission_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monthly_salary` int(11) NOT NULL,
  `date_of_birth` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `religion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permanent_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blood_group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `height` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight_as_on_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `previous_school` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_account_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `drive_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `driver_contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `result` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `registration_id`, `user_name`, `nid`, `role`, `birth_registration_no`, `name`, `class`, `roll`, `section`, `admission_date`, `monthly_salary`, `date_of_birth`, `mobile_no`, `email`, `religion`, `current_address`, `permanent_address`, `blood_group`, `height`, `weight`, `weight_as_on_date`, `previous_school`, `bank_account_number`, `bank_name`, `bank_code`, `drive_name`, `driver_contact`, `result`, `password`, `created_at`, `updated_at`) VALUES
(1, 'st5245', 'test.student', '546545135', 0, '54541246421', 'Test Student', 'class tow', 35, 'A', '2022-08-04 08:11:24', 4265, '2022-08-01T04:41:13.000000Z', '01720515258', NULL, 'Islam', '211 dhaka', '211 dhaka', 'A+(ve)', '5 f 5 in', '70 kg', '75 kg', 'Unknown', 'adjad44ag', 'Bangladesh bank', '55222', 'Driver name', '452454555', 'pass', '$2y$10$ceO5w72mC7bWpV51NJGB..Gf6eIeGQqK11YvoCQYyW2iIY.hHaAjK', '2022-08-08 15:13:25', '2022-08-08 15:13:25'),
(2, '1155', '115', 'nid', 15, 'birth_registration_no', 'name', 'class', 1, 'section', 'admission_date', 11115, '2022-08-04 08:11:24', 'mobile_no', NULL, 'religionadsf', 'current_address', 'permanent_address', 'blood_group', 'height', 'weightadf', 'weight_as_on_date', 'previous_schoolfa', 'bank_account_number', 'bank_name', 'bank_code', 'drive_name', 'driver_contact', 'result', 'password', '2022-08-08 10:11:01', '2022-08-08 10:11:01'),
(3, '11', '11', 'nid', 1, 'birth_registration_no', 'name', 'class', 1, 'section', 'admission_date', 1111, '2022-08-04 08:11:24', 'mobile_no', NULL, 'religion', 'current_address', 'permanent_address', 'blood_group', 'height', 'weight', 'weight_as_on_date', 'previous_school', 'bank_account_number', 'bank_name', 'bank_code', 'drive_name', 'driver_contact', 'result', 'password', '2022-08-08 10:14:48', '2022-08-08 10:14:48'),
(4, '11', '11', 'nid', 1, 'birth_registration_no', 'name', 'class', 1, 'section', 'admission_date', 1111, '2022-08-04 08:11:24', 'mobile_no', NULL, 'religion', 'current_address', 'permanent_address', 'blood_group', 'height', 'weight', 'weight_as_on_date', 'previous_school', 'bank_account_number', 'bank_name', 'bank_code', 'drive_name', 'driver_contact', 'result', 'password', '2022-08-08 10:15:50', '2022-08-08 10:15:50'),
(6, '11', '11', 'nid', 1, 'birth_registration_no', 'name', 'class', 1, 'section', 'admission_date', 1111, '2022-08-04 08:11:24', 'mobile_no', 'rakib@mail.com', 'religion', 'current_address', 'permanent_address', 'blood_group', 'height', 'weight', 'weight_as_on_date', 'previous_school', 'bank_account_number', 'bank_name', 'bank_code', 'drive_name', 'driver_contact', 'result', '1234', '2022-08-08 10:16:31', '2022-08-08 10:16:31'),
(7, '11', '11', 'nid', 1, 'birth_registration_no', 'name', 'class', 1, 'section', 'admission_date', 1111, '2022-08-04 08:11:24', 'mobile_no', NULL, 'religion', 'current_address', 'permanent_address', 'blood_group', 'height', 'weight', 'weight_as_on_date', 'previous_school', 'bank_account_number', 'bank_name', 'bank_code', 'drive_name', 'driver_contact', 'result', 'password', '2022-08-11 10:45:27', '2022-08-11 10:45:27'),
(8, 'st5245', 'test.student', '546545135', 0, '54541246421', 'Test Student', 'class tow', 35, 'A', NULL, 4265, '2022-08-01T04:41:13.000000Z', '01720515258', 'student1@gmail.com', 'Islam', '211 dhaka', '211 dhaka', 'A+(ve)', '5 f 5 in', '70 kg', '75 kg', 'Unknown', 'adjad44ag', 'Bangladesh bank', '55222', 'Driver name', '452454555', 'pass', '$2y$10$SCN1P9.n0YgEA9sgSWI2TeCrwKDHdY7JloPU/JaWAfXPIV5xbqT0S', '2022-08-14 19:46:20', '2022-08-14 19:46:20');

-- --------------------------------------------------------

--
-- Table structure for table `student_attendances`
--

CREATE TABLE `student_attendances` (
  `id` int(10) UNSIGNED NOT NULL,
  `std_id` int(10) UNSIGNED DEFAULT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remark` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_reports`
--

CREATE TABLE `student_reports` (
  `id` int(10) UNSIGNED NOT NULL,
  `std_id` int(11) NOT NULL,
  `exam_type` int(11) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `obtained_marks` int(11) NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `section` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_reports`
--

INSERT INTO `student_reports` (`id`, `std_id`, `exam_type`, `total_marks`, `obtained_marks`, `file`, `class`, `subject`, `section`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 524, 521, '1660456154.jpg', 'class one', 'English', 'A', '2022-08-14 15:49:14', '2022-08-14 15:49:14'),
(2, 2, 1, 524, 521, '1660457829.jpg', 'class one', 'English', 'A', '2022-08-14 16:17:09', '2022-08-14 16:17:09'),
(3, 4, 2, 5555, 558, '1660462668.pdf', 'Class 6', 'Biology', 'Section C', '2022-08-14 17:37:48', '2022-08-14 17:37:48'),
(4, 8, 1, 524, 521, '1660471444.jpg', 'class one', 'English', 'A', '2022-08-14 20:04:04', '2022-08-14 20:04:04'),
(5, 8, 1, 524, 521, '1660475981.pdf', 'class one', 'English', 'A', '2022-08-14 21:19:41', '2022-08-14 21:19:41'),
(6, 9, 2, 8585, 85858, '1660477836.pdf', 'Class 2', 'Science', 'Section C', '2022-08-14 21:50:36', '2022-08-14 21:50:36'),
(7, 8, 3, 2675, 54882, '1660477939.pdf', 'Class 2', 'Bangla', 'Section C', '2022-08-14 21:52:19', '2022-08-14 21:52:19'),
(8, 3, 3, 555, 141, '1660619991.pdf', 'Class 3', 'Science', 'Section B', '2022-08-16 13:19:51', '2022-08-16 13:19:51'),
(9, 3, 3, 57425, 44242, '1660620267.pdf', 'Class 4', 'Science', 'Section C', '2022-08-16 13:24:27', '2022-08-16 13:24:27');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(11) NOT NULL DEFAULT 0,
  `profile_id` int(11) NOT NULL DEFAULT 0,
  `device_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `profile_id`, `device_key`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Md Masud Rana', 'masudrana35362@gmail.com', NULL, '$2y$10$cE6OIJmOnH2l7ZTn8esW6OdKR5SevjIlU1KXbx9437eTHlhcYBeQW', 0, 0, NULL, NULL, '2022-08-04 02:14:10', '2022-08-04 02:14:10'),
(2, 'Test Student', 'test99@gmail.com', NULL, '$2y$10$l2R4Z0sBvUH5kzaeRgJIu.nHWmQf50Vm/KI0hE18u.EI6bFdxrzFe', 1, 1, NULL, NULL, '2022-08-08 15:13:25', '2022-08-08 15:13:25'),
(3, 'Test Parent', 'parent1@gmail.com', NULL, '$2y$10$VL4VL2YjOth1azGTPdurwu8g9DFWp3vf2fmZ7gOdATUlDch5.KxFy', 2, 1, NULL, NULL, '2022-08-14 14:02:10', '2022-08-14 14:02:10'),
(4, 'Test Teacher', 'teacher1@gmail.com', NULL, '$2y$10$Zf3HAwj2DINuINUSZGTQN.6G5IKZm9rrrTlpURHJ7Cao6tOkj/Bau', 3, 6, NULL, NULL, '2022-08-14 14:54:38', '2022-08-14 14:54:38'),
(5, 'Test Student', 'student1@gmail.com', NULL, '$2y$10$75EVT/OYXtOMutkEBeMnluQi.Cwg/9MV/3QQnurrgfXgcoceW4hNu', 1, 8, NULL, NULL, '2022-08-14 19:46:20', '2022-08-14 19:46:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class_times`
--
ALTER TABLE `class_times`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee_attendances`
--
ALTER TABLE `employee_attendances`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense_income_type`
--
ALTER TABLE `expense_income_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `fees`
--
ALTER TABLE `fees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fees_total_payable`
--
ALTER TABLE `fees_total_payable`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `std_id` (`std_id`);

--
-- Indexes for table `fines`
--
ALTER TABLE `fines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `homework`
--
ALTER TABLE `homework`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `income`
--
ALTER TABLE `income`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leaves`
--
ALTER TABLE `leaves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `list_class`
--
ALTER TABLE `list_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `list_section`
--
ALTER TABLE `list_section`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `list_subject`
--
ALTER TABLE `list_subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parents_std_id_index` (`std_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payment_details`
--
ALTER TABLE `payment_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `reports_guardian`
--
ALTER TABLE `reports_guardian`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salaries`
--
ALTER TABLE `salaries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_attendances`
--
ALTER TABLE `student_attendances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_attendances_std_id_index` (`std_id`);

--
-- Indexes for table `student_reports`
--
ALTER TABLE `student_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class_times`
--
ALTER TABLE `class_times`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employee_attendances`
--
ALTER TABLE `employee_attendances`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `expense_income_type`
--
ALTER TABLE `expense_income_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fees`
--
ALTER TABLE `fees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `fees_total_payable`
--
ALTER TABLE `fees_total_payable`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `fines`
--
ALTER TABLE `fines`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `homework`
--
ALTER TABLE `homework`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `income`
--
ALTER TABLE `income`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `leaves`
--
ALTER TABLE `leaves`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `list_class`
--
ALTER TABLE `list_class`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `list_section`
--
ALTER TABLE `list_section`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `list_subject`
--
ALTER TABLE `list_subject`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=270;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payment_details`
--
ALTER TABLE `payment_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `reports_guardian`
--
ALTER TABLE `reports_guardian`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `salaries`
--
ALTER TABLE `salaries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `student_attendances`
--
ALTER TABLE `student_attendances`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_reports`
--
ALTER TABLE `student_reports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `parents`
--
ALTER TABLE `parents`
  ADD CONSTRAINT `parents_std_id_foreign` FOREIGN KEY (`std_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_attendances`
--
ALTER TABLE `student_attendances`
  ADD CONSTRAINT `student_attendances_std_id_foreign` FOREIGN KEY (`std_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
